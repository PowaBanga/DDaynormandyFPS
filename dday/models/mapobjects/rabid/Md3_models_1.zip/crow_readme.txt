crow.md3  (mapobject)

*************
credits
*************
thanks to
-dan(model)
-thomas(model)
-me(skin)
*************

unzip the contents into your baseq3 folder, they will be extracted to baseq3/models/mapobjects/crow

if ou have problems with these simple instructions, i will smack you because your a putz, but in any case, email: mikemajernik@hotmail.com

thanks a bunch

p.s.

dan and thomas kick ass!