Different versions for the multiplant model
(all of them are placed in the models/mapobjects/multiplant directory)

multiplant.md3			a plant whose name i don't remember 
multiplant_b.md3		a banana plant
multiplant_f.md3		a fern 
multiplant_f2.md3		another fern
multiplant_p.md3		a somewhat battered palm
multiplant_p2.md3		another palm
multiplant_a.md3		another plant
multiplant_e.md3		an evil plant meant to hurt the player on contact
				two shader passes plus lightmap, vertex deformation


* SEE multiplant_v2.txt, multiplant.txt AND multiplant2.txt FOR MORE INFO *