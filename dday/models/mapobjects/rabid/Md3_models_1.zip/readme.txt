Name : Skeletons Model Add-on for Quake 3: Arena
Author : Kevin Kolk aka Cyber 
Email : kkolk@accn.org
URL : http://www.accn.org/~kkolk/ 

Description:

A set of posed models based off id's bones player model.  They all share the same skin and texture with that player model so no skins are included in this archive.

A few of the poses where created to be specific to the map I was creating so they might not work well else where.  Most are very generic though.

Construction

Editor Used : 3D Studio Max 4.0, Pop'n'Fresh's 3D Studio MD3 Plugin, NPherno's MD3 Compiler
Known Bugs : None
Build Time : 4-5 Hours

Copyright / Permissions:

Original Base Model is copyright id Software, Inc.  You may use these models in your maps as long as you give
me credit.  You may modify, edit, the models as much as you want. (Hey I did, why shouldn't you?)

QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks of id Software, Inc.