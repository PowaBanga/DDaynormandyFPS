Oak-tree Mapmodel (c)GrimReaper

Files included in the .pk3 :

Oak.shader
Oakstamm.jpg
Oakstamm2.jpg
Oakblaetter.tga
Oakblaetter2.tga
Oakblaetter3.tga
Oak1.md3 (555 polys)
Oak2.md3 (555 polys)
Oak3.md3 (555 polys)
Oak4.md3 (418 polys)
Oak5.md3 (418 polys)

==========================================
All files are done by:

Krischan "GrimReaper" Makowka

E-mail:  Grimreaper@planetquake.com
